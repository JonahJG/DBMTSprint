--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Best Kind Brewery";
--
-- Name: Best Kind Brewery; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Best Kind Brewery" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Canada.1252';


ALTER DATABASE "Best Kind Brewery" OWNER TO postgres;

\connect -reuse-previous=on "dbname='Best Kind Brewery'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Address" (
    "AddressID" integer NOT NULL,
    "VenueID" integer NOT NULL,
    "StreetAddress" character varying(128) NOT NULL,
    "City" character varying(64) NOT NULL,
    "Province" character varying(64) NOT NULL,
    "PostalCode" character varying(12) NOT NULL
);


ALTER TABLE public."Address" OWNER TO postgres;

--
-- Name: BeerCategories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BeerCategories" (
    "CategoryID" integer NOT NULL,
    "CategoryName" character varying(64) NOT NULL
);


ALTER TABLE public."BeerCategories" OWNER TO postgres;

--
-- Name: Beers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Beers" (
    "BeerID" integer NOT NULL,
    "CategoryID" integer NOT NULL,
    "BeerName" character varying(32) NOT NULL,
    "ABV" numeric NOT NULL,
    "Description" character varying(128) NOT NULL
);


ALTER TABLE public."Beers" OWNER TO postgres;

--
-- Name: Compost; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Compost" (
    "CompostID" integer NOT NULL,
    "EventID" integer NOT NULL,
    "AddressID" integer NOT NULL,
    "Weight" numeric NOT NULL
);


ALTER TABLE public."Compost" OWNER TO postgres;

--
-- Name: Customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Customers" (
    "CustomerID" integer NOT NULL,
    "FirstName" character varying(36) NOT NULL,
    "LastName" character varying(64) NOT NULL,
    "Email" character varying(128)
);


ALTER TABLE public."Customers" OWNER TO postgres;

--
-- Name: Deliveries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Deliveries" (
    "DeliveryID" integer NOT NULL,
    "EventID" integer,
    "BeerID" integer,
    "SupplierID" integer NOT NULL,
    "Quantity" integer NOT NULL,
    "TotalPrice" money NOT NULL
);


ALTER TABLE public."Deliveries" OWNER TO postgres;

--
-- Name: Events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Events" (
    "EventID" integer NOT NULL,
    "EventName" character varying(128) NOT NULL,
    "Date" date NOT NULL,
    "Description" character varying(600) NOT NULL
);


ALTER TABLE public."Events" OWNER TO postgres;

--
-- Name: Recycling; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Recycling" (
    "RecyclingID" integer NOT NULL,
    "EventID" integer NOT NULL,
    "AddressID" integer NOT NULL,
    "Weight" numeric NOT NULL
);


ALTER TABLE public."Recycling" OWNER TO postgres;

--
-- Name: Rewards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Rewards" (
    "RewardsID" integer NOT NULL,
    "CustomerID" integer NOT NULL,
    "Points" integer
);


ALTER TABLE public."Rewards" OWNER TO postgres;

--
-- Name: Sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sales" (
    "SaleID" integer NOT NULL,
    "EventID" integer,
    "BeerID" integer,
    "EmployeeID" integer,
    "Quantity" integer,
    "Date" date NOT NULL,
    "Price" money NOT NULL
);


ALTER TABLE public."Sales" OWNER TO postgres;

--
-- Name: SalesTeam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SalesTeam" (
    "EmployeeID" integer NOT NULL,
    "FirstName" character varying(32) NOT NULL,
    "LastName" character varying(32) NOT NULL,
    "StreetAddress" character(86) NOT NULL,
    "City" character varying(64) NOT NULL,
    "Prov" character varying(64) NOT NULL
);


ALTER TABLE public."SalesTeam" OWNER TO postgres;

--
-- Name: Suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Suppliers" (
    "SupplierID" integer NOT NULL,
    "SupplierName" character varying(128) NOT NULL,
    "Phone" character varying(16) NOT NULL
);


ALTER TABLE public."Suppliers" OWNER TO postgres;

--
-- Name: VenueLocations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VenueLocations" (
    "VenueID" integer NOT NULL,
    "EventID" integer NOT NULL,
    "VenueName" character varying(128) NOT NULL,
    "VenueCapacity" integer
);


ALTER TABLE public."VenueLocations" OWNER TO postgres;

--
-- Data for Name: Address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Address" ("AddressID", "VenueID", "StreetAddress", "City", "Province", "PostalCode") FROM stdin;
\.
COPY public."Address" ("AddressID", "VenueID", "StreetAddress", "City", "Province", "PostalCode") FROM '$$PATH$$/3407.dat';

--
-- Data for Name: BeerCategories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BeerCategories" ("CategoryID", "CategoryName") FROM stdin;
\.
COPY public."BeerCategories" ("CategoryID", "CategoryName") FROM '$$PATH$$/3414.dat';

--
-- Data for Name: Beers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Beers" ("BeerID", "CategoryID", "BeerName", "ABV", "Description") FROM stdin;
\.
COPY public."Beers" ("BeerID", "CategoryID", "BeerName", "ABV", "Description") FROM '$$PATH$$/3413.dat';

--
-- Data for Name: Compost; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Compost" ("CompostID", "EventID", "AddressID", "Weight") FROM stdin;
\.
COPY public."Compost" ("CompostID", "EventID", "AddressID", "Weight") FROM '$$PATH$$/3408.dat';

--
-- Data for Name: Customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Customers" ("CustomerID", "FirstName", "LastName", "Email") FROM stdin;
\.
COPY public."Customers" ("CustomerID", "FirstName", "LastName", "Email") FROM '$$PATH$$/3410.dat';

--
-- Data for Name: Deliveries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Deliveries" ("DeliveryID", "EventID", "BeerID", "SupplierID", "Quantity", "TotalPrice") FROM stdin;
\.
COPY public."Deliveries" ("DeliveryID", "EventID", "BeerID", "SupplierID", "Quantity", "TotalPrice") FROM '$$PATH$$/3409.dat';

--
-- Data for Name: Events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Events" ("EventID", "EventName", "Date", "Description") FROM stdin;
\.
COPY public."Events" ("EventID", "EventName", "Date", "Description") FROM '$$PATH$$/3402.dat';

--
-- Data for Name: Recycling; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Recycling" ("RecyclingID", "EventID", "AddressID", "Weight") FROM stdin;
\.
COPY public."Recycling" ("RecyclingID", "EventID", "AddressID", "Weight") FROM '$$PATH$$/3406.dat';

--
-- Data for Name: Rewards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Rewards" ("RewardsID", "CustomerID", "Points") FROM stdin;
\.
COPY public."Rewards" ("RewardsID", "CustomerID", "Points") FROM '$$PATH$$/3411.dat';

--
-- Data for Name: Sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Sales" ("SaleID", "EventID", "BeerID", "EmployeeID", "Quantity", "Date", "Price") FROM stdin;
\.
COPY public."Sales" ("SaleID", "EventID", "BeerID", "EmployeeID", "Quantity", "Date", "Price") FROM '$$PATH$$/3405.dat';

--
-- Data for Name: SalesTeam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SalesTeam" ("EmployeeID", "FirstName", "LastName", "StreetAddress", "City", "Prov") FROM stdin;
\.
COPY public."SalesTeam" ("EmployeeID", "FirstName", "LastName", "StreetAddress", "City", "Prov") FROM '$$PATH$$/3404.dat';

--
-- Data for Name: Suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Suppliers" ("SupplierID", "SupplierName", "Phone") FROM stdin;
\.
COPY public."Suppliers" ("SupplierID", "SupplierName", "Phone") FROM '$$PATH$$/3412.dat';

--
-- Data for Name: VenueLocations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VenueLocations" ("VenueID", "EventID", "VenueName", "VenueCapacity") FROM stdin;
\.
COPY public."VenueLocations" ("VenueID", "EventID", "VenueName", "VenueCapacity") FROM '$$PATH$$/3403.dat';

--
-- Name: Address Address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address"
    ADD CONSTRAINT "Address_pkey" PRIMARY KEY ("AddressID");


--
-- Name: BeerCategories BeerCategories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BeerCategories"
    ADD CONSTRAINT "BeerCategories_pkey" PRIMARY KEY ("CategoryID");


--
-- Name: Beers Beers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Beers"
    ADD CONSTRAINT "Beers_pkey" PRIMARY KEY ("BeerID");


--
-- Name: Compost Compost_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Compost"
    ADD CONSTRAINT "Compost_pkey" PRIMARY KEY ("CompostID");


--
-- Name: Customers Customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customers"
    ADD CONSTRAINT "Customers_pkey" PRIMARY KEY ("CustomerID");


--
-- Name: Deliveries Deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Deliveries"
    ADD CONSTRAINT "Deliveries_pkey" PRIMARY KEY ("DeliveryID");


--
-- Name: Events Events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Events"
    ADD CONSTRAINT "Events_pkey" PRIMARY KEY ("EventID");


--
-- Name: Recycling Recycling_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recycling"
    ADD CONSTRAINT "Recycling_pkey" PRIMARY KEY ("RecyclingID");


--
-- Name: Rewards Rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Rewards"
    ADD CONSTRAINT "Rewards_pkey" PRIMARY KEY ("RewardsID");


--
-- Name: SalesTeam Sales Team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SalesTeam"
    ADD CONSTRAINT "Sales Team_pkey" PRIMARY KEY ("EmployeeID");


--
-- Name: Sales Sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sales"
    ADD CONSTRAINT "Sales_pkey" PRIMARY KEY ("SaleID");


--
-- Name: Suppliers Suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Suppliers"
    ADD CONSTRAINT "Suppliers_pkey" PRIMARY KEY ("SupplierID");


--
-- Name: VenueLocations VenueLocations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VenueLocations"
    ADD CONSTRAINT "VenueLocations_pkey" PRIMARY KEY ("VenueID");


--
-- Name: Compost AddressID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Compost"
    ADD CONSTRAINT "AddressID" FOREIGN KEY ("AddressID") REFERENCES public."Address"("AddressID") NOT VALID;


--
-- Name: Recycling AddressID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recycling"
    ADD CONSTRAINT "AddressID" FOREIGN KEY ("AddressID") REFERENCES public."Address"("AddressID") NOT VALID;


--
-- Name: Deliveries BeerID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Deliveries"
    ADD CONSTRAINT "BeerID" FOREIGN KEY ("BeerID") REFERENCES public."Beers"("BeerID") NOT VALID;


--
-- Name: Sales BeerID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sales"
    ADD CONSTRAINT "BeerID" FOREIGN KEY ("BeerID") REFERENCES public."Beers"("BeerID") NOT VALID;


--
-- Name: Beers CategoryID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Beers"
    ADD CONSTRAINT "CategoryID" FOREIGN KEY ("CategoryID") REFERENCES public."BeerCategories"("CategoryID") NOT VALID;


--
-- Name: Rewards CustomerID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Rewards"
    ADD CONSTRAINT "CustomerID" FOREIGN KEY ("CustomerID") REFERENCES public."Customers"("CustomerID") NOT VALID;


--
-- Name: Sales EmployeeID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sales"
    ADD CONSTRAINT "EmployeeID" FOREIGN KEY ("EmployeeID") REFERENCES public."SalesTeam"("EmployeeID") NOT VALID;


--
-- Name: Compost EventID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Compost"
    ADD CONSTRAINT "EventID" FOREIGN KEY ("EventID") REFERENCES public."Events"("EventID") NOT VALID;


--
-- Name: Deliveries EventID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Deliveries"
    ADD CONSTRAINT "EventID" FOREIGN KEY ("EventID") REFERENCES public."Events"("EventID") NOT VALID;


--
-- Name: Recycling EventID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recycling"
    ADD CONSTRAINT "EventID" FOREIGN KEY ("EventID") REFERENCES public."Events"("EventID") NOT VALID;


--
-- Name: Sales EventID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sales"
    ADD CONSTRAINT "EventID" FOREIGN KEY ("EventID") REFERENCES public."Events"("EventID") NOT VALID;


--
-- Name: VenueLocations Events; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VenueLocations"
    ADD CONSTRAINT "Events" FOREIGN KEY ("EventID") REFERENCES public."Events"("EventID");


--
-- Name: Deliveries SupplierID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Deliveries"
    ADD CONSTRAINT "SupplierID" FOREIGN KEY ("SupplierID") REFERENCES public."Suppliers"("SupplierID") NOT VALID;


--
-- Name: Address VenueID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Address"
    ADD CONSTRAINT "VenueID" FOREIGN KEY ("VenueID") REFERENCES public."VenueLocations"("VenueID") NOT VALID;


--
-- PostgreSQL database dump complete
--

